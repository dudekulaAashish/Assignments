﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookProject
{
    class Books
    {

        public int bookId,price;
        public string bookName, bookAuthor, description, ISBNCode;

        public Books()
        {

        }

        public Books(int bookId, string bookName, string bookAuthor,string ISBNCode, int price, string description)
        {
            this.bookId = bookId;
            this.price = price;
            this.ISBNCode = ISBNCode;
            this.bookName = bookName;
            this.bookAuthor = bookAuthor;
            this.description = description;
        }


        public override string ToString()
        {
            return $"BookId : {bookId}; Book Name : {bookName}; Author : {bookAuthor};  ISBN-Code : {ISBNCode}; Price : {price}; Description : {description}; ";
        }
    }

    class BookItem
    {
        public int bookId, price;
        public string bookName, bookAuthor, description, ISBNCode;

    }


    class Program
    {
        public static void DoAddOperation()
        {

        }
        static void displayArr(List<Books> BooksList)
        {
            foreach (Books item in BooksList)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            List<Books> BooksList = new List<Books>
            {
                new Books(1, "Think and Grow Rich", "Napolean Hill", "893 - 829 - 379", 299, "abcd"),
                new Books(2, "The Power of Your Subconscious Mind", "Joseph Murphu",  "893 - 829 - 379", 379, "efgh"),
                new Books(3, "The Psychology of Money", "Morgan Housel",  "893 - 829 - 379", 289, "ijkl"),
                new Books(4, "Wings of Fire: An Autobiography of Abdul Kalam", "Arun Tiwari",  "893 - 829 - 379", 399, "mnop"),
            };

            displayArr(BooksList);
            Console.WriteLine("");
            Console.WriteLine("-------Choose an option to perform desired operations--------- ");
            Console.WriteLine(" Type a number, and press Enter: ");
            Console.WriteLine("\t Press 1 : To Edit the Book");
            Console.WriteLine("\t Press 2 : To Delete the Book");
            Console.WriteLine("\t Press 3 : To Add the Book");
            Console.WriteLine("\t Press 4 : To Show the desired Book description");
            Console.WriteLine("\t Press 5 : To Display the desired Book Details ");
            Console.WriteLine("\t Enter None of the above numbers to EXIT");

            bool optionInput = false;
            int option = 0;
            while(optionInput == false)
            {
                Console.WriteLine("Please choose an option");
                optionInput = Int32.TryParse(Console.ReadLine(),out option);
                
            }

            bool bookIdInput = false;
            int enterBookId = 0;
            int indexPosition = 0;
            bool isContains = false;

            switch (option)
            {
                case 1:
                    
                    while (bookIdInput == false)
                    {
                        Console.WriteLine("Enter the BookId to which you want to edit");
                        bookIdInput = Int32.TryParse(Console.ReadLine(), out enterBookId);
                    }

                    foreach (Books item in BooksList)
                    { 
                        if (item.bookId == enterBookId)
                        {
                            indexPosition = BooksList.IndexOf(item);
                            isContains = true;
                        }
                    }

                    if (isContains)
                    {
                        Console.WriteLine($"Which of the book details you would like to edit for bookId {enterBookId}");
                       
                        //List <object> editedBook = new List<object>();
                        Console.WriteLine("---Choose the option---");
                        Console.WriteLine("\t Press 1 : New Book Name");
                        Console.WriteLine("\t Press 2 : New Book Author");
                        Console.WriteLine("\t Press 3 : New Book Price");
                        Console.WriteLine("\t Press 4 : New Book Description");
                        Console.WriteLine("\t Press 5 : New Book ISBN code");
                        Console.WriteLine("\t Enter None of the above numbers to EXIT");

                        bool optionNum = false;
                        int optionVal = 0;
                        while (optionNum == false)
                        {
                            Console.WriteLine("Please choose an option");
                            optionNum = Int32.TryParse(Console.ReadLine(), out optionVal);
                        }

                       switch(optionVal)
                        {
                            case 1:
                                string userInputBookName = Console.ReadLine();
                                BooksList[indexPosition].bookName = userInputBookName;
                                
                                break;
                            case 2:
                                string userInputBookAuthor = Console.ReadLine();
                                BooksList[indexPosition].bookAuthor = userInputBookAuthor;
                                break;
                            case 3:
                                bool optionPrice = false;
                                int userInputBookPrice = 0;
                                while (optionPrice == false)
                                {
                                    Console.WriteLine("Please enter a new price");
                                    optionPrice = Int32.TryParse(Console.ReadLine(), out userInputBookPrice);
  
                                }

                                BooksList[indexPosition].price = userInputBookPrice;
                                break;
                            case 4:
                                string userInputDesc = Console.ReadLine();
                                BooksList[indexPosition].description = userInputDesc;
                                break;
                            case 5:
                                string userInputISBNcode = Console.ReadLine();
                                BooksList[indexPosition].ISBNCode = userInputISBNcode;
                                break;
                            default:
                                Console.WriteLine("Please check the options you have");
                                break;
                        }
                        Console.WriteLine("The Edited Book Details are");
                        Console.WriteLine(BooksList[indexPosition]);
                    }
                    else
                    {
                        Console.WriteLine("The entered bookId is not present in the BooksList");
                    }

                    break;

                case 2:

                    Console.WriteLine("Enter BookId which you want to delete");
                    while (bookIdInput == false)
                    {
                        bookIdInput = Int32.TryParse(Console.ReadLine(), out enterBookId);
                    }

                    foreach (Books item in BooksList)
                    {
                            
                        if (item.bookId == enterBookId) 
                        {
                            indexPosition = BooksList.IndexOf(item);
                            isContains = true;
                        }
                    }

                    if(isContains)
                    {
                        BooksList.RemoveAt(indexPosition);
                        displayArr(BooksList);
                    }
                    else
                    {
                        Console.WriteLine("The entered bookId is not present in the BooksList");
                    }

                    break;

                case 3:
                    bool priceInput = true;
                    bool booksInput = false;
                    int n = 0;
                    Console.WriteLine(" ");
                    Console.WriteLine("--------Enter New Book Details--------");
                    while (booksInput == false)
                    {
                        Console.WriteLine("Enter the no of books you want to enter");
                        booksInput = int.TryParse(Console.ReadLine(), out n);
                    }

                    for (int i = 1; i <= n; i++)
                    {
                        Console.WriteLine("Enter the Book Name");
                        string bookName = Console.ReadLine();
                        Console.WriteLine("Enter the Author");
                        string bookAuthor = Console.ReadLine();
                        Console.WriteLine("Enter the ISBNCode");
                        string ISBNCode = Console.ReadLine();
                        Console.WriteLine("Enter the Description");
                        string description = Console.ReadLine();
                        priceInput = true;
                        while (priceInput)
                        {
                            Console.WriteLine("Enter the Price of the book");
                            int price;
                            bool result = Int32.TryParse(Console.ReadLine(), out price);
                            if (result)
                            {
                                BooksList.Add(new Books(BooksList.Count + i, bookName, bookAuthor, ISBNCode, price, description));
                                priceInput = false;
                            }

                        }

                        displayArr(BooksList);
                    }

                    break;

                case 4:
                    Console.WriteLine("Enter the BookId for which you want to see the description");
                  
                    while (bookIdInput == false)
                    {
                        bookIdInput = Int32.TryParse(Console.ReadLine(), out enterBookId);
                        bookIdInput = true;
                    }

                    foreach (Books item in BooksList)
                    {

                        if (item.bookId == enterBookId)
                        {
                            indexPosition = BooksList.IndexOf(item);
                            isContains = true;
                        }
                    }

                    if (isContains)
                    {
                        Console.WriteLine($"The description of BookId {enterBookId} is {BooksList[indexPosition].description}");
                    }
                    else
                    {
                        Console.WriteLine("The entered bookId is not present in the BooksList");
                    }

                    break;

                case 5:
                    Console.WriteLine("Enter the BookId for which you want to see the book details");
                    while (bookIdInput == false)
                    {
                        bookIdInput = Int32.TryParse(Console.ReadLine(), out enterBookId);
                        bookIdInput = true;
                    }

                    foreach (Books item in BooksList)
                    {

                        if (item.bookId == enterBookId)
                        {
                            indexPosition = BooksList.IndexOf(item);
                            isContains = true;
                        }
                    }

                    if (isContains)
                    {
                        Console.WriteLine($"The Book details of BookId {enterBookId} is {BooksList[indexPosition]}");
                    }
                    else
                    {
                        Console.WriteLine("The entered bookId is not present in the BooksList");
                    }
                    break;
                default:
                    Console.WriteLine("The entered option is not in the given options");
                    break;
            }
            
            Console.ReadLine();
        }
    }
}
