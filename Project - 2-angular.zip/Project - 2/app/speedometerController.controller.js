myAppSpeedometer.controller("speedController", function($scope){
    $scope.speed = 0;
    $scope.Accelerate = function(speed)
    {
        if($scope.speed < 200 && $scope.speed >= 0)
        {
            $scope.speed = $scope.speed + 20;
        }
        
        
    }
    $scope.Brake = function(speed)
    {
        if($scope.speed <= 200 && $scope.speed > 0)
        {
            $scope.speed = $scope.speed - 10;
        }
        
    }
});