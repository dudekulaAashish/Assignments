booksApp.controller("booksDisplayController", function($scope){

    $scope.headerItemsArr =
    [
        {id:1, elementName:"Home", className:"nav-item active"},
        {id:2, elementName:"Favourite", className:"nav-item active"},
        {id:3, elementName:"Top Sellers", className:"nav-itenm active"},
    ]

    $scope.booksArr = 
    [
        {id:1,bookUrl:"D:\\Projects On Angular\\Project-Book\\Images\\b-1.jpg",bookTitle:"Think and Grow Rich", author:"Napolean Hill",publishedDate:"June 2 2015", ISBN :978-3-16-148410-0,price:399,isFavorite:false,heartUrl:"D:\\Projects On Angular\\Project-Book\\Images\\heart-empty.png", description:"An exquisitely designed leather-bound edition of one of the best inspirational books ever written, think and Grow Rich is probably the most important financial book you can ever hope to read. Inspiring generations of readers since the time it was first published in 1937, think and Grow Rich Hills biggest best-sellerhas been used by millions of business leaders around the world to create a concrete plan for success that, when followed, never fails. However, it will be incorrect to limit the book to be just about achieving financial richness. A motivational personal development and self-help book, its core strength lies in the fact that it not only expounds upon material wealth but that at the heart of it, It is a treatise on helping individuals succeed in all lines of work and to do or be almost anything they want in this world. Think and Grow Rich has been listed in John C. Maxwells a lifetime must read books list, and also ranked as the sixth paperback business book years after it was first published by business week Magazines best-seller list. This edition comes with a ribbon bookmark, gilded edges and beautiful endpapers. Ideal to be read and treasured, it makes for a perfect addition to any library."},
        {id:2,bookUrl:"D:\\Projects On Angular\\Project-Book\\Images\\b-2.jpg",bookTitle:"The Power of Your Subconscious Mind", publishedDate:"March 12 2012",author:"Joseph Murphu", ISBN :678-3-16-148410-0,price:99,isFavorite:false,heartUrl:"D:\\Projects On Angular\\Project-Book\\Images\\heart-empty.png",description:"This remarkable book by Dr. Joseph Murphy, one of the pioneering voices of affirmative thinking, will unlock for you the truly staggering powers of your subconscious mind. Combining time-honored spiritual wisdom with cutting edge scientific research, Dr. Murphy explains how the subconscious mind influences every single thing that you do and how, by understanding it and learning to control its incredible force, you can improve the quality of your daily life.Everything, from the promotion that you wanted and the raise you think you deserve, to overcoming phobias and bad habits and strengthening interpersonal relationships, the Power of Your Subconscious Mind will open a world of happiness, success, prosperity and peace for you. It will change your life and your world by changing your beliefs."},
        {id:3,bookUrl:"D:\\Projects On Angular\\Project-Book\\Images\\b-3.jpg",bookTitle:"The Psychology of Money", publishedDate:"August 20 2015",author:"Morgan Housel", ISBN :348-35-16-148980-0,price:283,isFavorite:false,heartUrl:"D:\\Projects On Angular\\Project-Book\\Images\\heart-empty.png",description:"Timeless lessons on wealth, greed, and happiness doing well with money isn?t necessarily about what you know. It?s about how you behave. And behavior is hard to teach, even to really smart people. How to manage money, invest it, and make business decisions are typically considered to involve a lot of mathematical calculations, where data and formulae tell us exactly what to do. But in the real world, people don?t make financial decisions on a spreadsheet. They make them at the dinner table, or in a meeting room, where personal history, your unique view of the world, ego, pride, marketing, and odd incentives are scrambled together. In the psychology of money, the author shares 19 short stories exploring the strange ways people think about money and teaches you how to make better sense of one of life?s most important matters."},
        {id:4,bookUrl:"D:\\Projects On Angular\\Project-Book\\Images\\b-4.jpg",bookTitle:"Wings of Fire: An Autobiography of Abdul Kalam ", publishedDate:"October 12 2015",author:"Arun Tiwari and A. P. J. Abdul Kalam", ISBN :328-30-26-123910-0,price:279,isFavorite:false,heartUrl:"D:\\Projects On Angular\\Project-Book\\Images\\heart-empty.png",description:"Every common man who by his sheer grit and hard work achieves success should share his story with the rest for they may find inspiration and strength to go on, in his story. The 'Wings of Fire' is one such autobiography by visionary scientist Dr. APJ Abdul Kalam, who from very humble beginnings rose to be the President of India. The book is full of insights, personal moments and life experiences of Dr. Kalam. It gives us an understanding on his journey of success."},
    ]

    $scope.bookSearch = "";
    $scope.searchBookItem = function(bookName)
    {
        $scope.booksArr = $scope.booksArr.filter(eachBook => {
            return eachBook.bookTitle == bookName;
        });
    }

    $scope.firstChar="";
    $scope.filteredList = function(item)
    {
        return item.bookTitle.toLowerCase().startsWith($scope.firstChar.toLowerCase());
    }

    $scope.onClickFavouriteBook = function(book)
    {
        if(!book.isFavorite)
        {
            book.heartUrl = "D:\\Projects On Angular\\Project-Book\\Images\\heart-fill.png";
            book.isFavorite = true;
        }
        else
        {
            book.heartUrl = "D:\\Projects On Angular\\Project-Book\\Images\\heart-empty.png";
            book.isFavorite = false;
        }
    } 

    $scope.onClickNavbar = function(value)
    {
        $scope.headerItemsArr.map(item =>
        {
            if(item.id == value.id)
            {
                item.className="nav-item active header-element";
            }
           else
           {
               item.className="nav-item active";
           }

            if(value.elementName == "Favourite")
            {
                $scope.booksArr = $scope.booksArr.filter(eachBook => {
                    return eachBook.isFavorite != false
                });
            }
        });
    }

    $scope.onClickDeleteBtn = function(value)
    {
        $scope.booksArr = $scope.booksArr.filter(eachBook => {
            return eachBook.id != value.id
        });
    }

    $scope.selectedBook = {};
    $scope.showEditBookForm = false ;
    $scope.onClickEditBookDetails = function(Obj)
    {
        $scope.showEditBookForm = true ;
        $scope.selectedBook = Obj; 
    }

    $scope.saveEditedBookEventHandler = function()
    {
        $scope.showEditBookForm = false ;
    }

    $scope.showAddBookForm = false;
    $scope.showAddBookEventHandler = function()
    {
        $scope.showAddBookForm = true;
    }

    $scope.$on("addNewBook",function(event,newBook){

        let lengthOfnewBook = Object.keys(newBook).length + 2;
        let lengthOfObjectInBookArr = Object.keys($scope.booksArr[0]).length;
       
        $scope.booksArr.push(newBook);
        $scope.showAddBookForm = false;
    });

    $scope.$on("cancelAddNewBook", function(){
        $scope.showAddBookForm = false; 
    }); 
});