booksApp.controller("bookAddController", function($scope){
    $scope.newBook=
    {
        id: $scope.booksArr.length + 1,
        isFavourite: false,
        heartUrl:"D:\\Projects On Angular\\Project-Book\\Images\\heart-empty.png",
        bookUrl:"D:\\Projects On Angular\\Project-Book\\Images\\.jpg",
    }

    $scope.errorMessage = "";

    $scope.saveDetailsEventHandler = function()
    {
        if($scope.addBookForm.$valid)
        {
            if(parseFloat($scope.newBook.price) <= 0)
            {
                $scope.errorMessage = "Price must be greater than zero";
                return;
            }
        }
        console.log("New Employee Details Entered", $scope.newBook);
        $scope.$emit("addNewBook", $scope.newBook);
    }

    $scope.cancelEventHandler = function()
    {
        $scope.$emit("cancelAddNewBook");
        $scope.newBook={}
    } 
    
});