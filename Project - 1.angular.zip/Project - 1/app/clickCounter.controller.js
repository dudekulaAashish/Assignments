myAppClickCounter.controller("clickCounterController", function($scope){

    $scope.counter = 0;
    $scope.onClickCounter = function()
    {
        $scope.counter = $scope.counter + 1;
    }
});